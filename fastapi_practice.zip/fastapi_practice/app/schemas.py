from pydantic import BaseModel, Field


class StudentBase(BaseModel):
    name: str = Field(..., example="Ayesha Khan")
    age: int = Field(..., ge=1, le=120, example=21)
    course: str = Field(..., example="Computer Science")
    email: str = Field(..., example="ayesha@example.com")


class StudentCreate(StudentBase):
    pass


class Student(StudentBase):
    id: int = Field(..., example=1)

    class Config:
        from_attributes = True
