from fastapi import FastAPI

from .routers.students import router as student_router

app = FastAPI(
    title="FastAPI Practice",
    description="Practice project with modular student endpoints storing data in JSON.",
    version="0.1.0",
)

app.include_router(student_router)


@app.get("/", summary="API health check")
def root() -> dict:
    return {"message": "FastAPI practice is running", "routes": ["/students", "/students/{student_id}"]}
