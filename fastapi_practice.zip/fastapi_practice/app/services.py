import json
from pathlib import Path
from typing import List

from .schemas import Student, StudentCreate

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "students.json"
DATA_FILE.parent.mkdir(parents=True, exist_ok=True)


def _load_students() -> List[dict]:
    if not DATA_FILE.exists():
        return []
    with DATA_FILE.open("r", encoding="utf-8") as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return []


def _save_students(students: List[dict]) -> None:
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(students, file, indent=2)


def get_all_students() -> List[Student]:
    return [Student(**student) for student in _load_students()]


def get_student(student_id: int) -> Student | None:
    for record in _load_students():
        if record.get("id") == student_id:
            return Student(**record)
    return None


def add_student(student_data: StudentCreate) -> Student:
    students = _load_students()
    next_id = max((student.get("id", 0) for student in students), default=0) + 1
    student = Student(id=next_id, **student_data.dict())
    students.append(student.dict())
    _save_students(students)
    return student
