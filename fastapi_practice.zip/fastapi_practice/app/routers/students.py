from fastapi import APIRouter, HTTPException, status
from typing import List

from ..schemas import Student, StudentCreate
from ..services import add_student, get_all_students, get_student

router = APIRouter(prefix="/students", tags=["students"])


@router.get("/", response_model=List[Student])
def list_students() -> List[Student]:
    """Return all saved students."""
    return get_all_students()


@router.get("/{student_id}", response_model=Student)
def read_student(student_id: int) -> Student:
    """Return a single student by ID."""
    student = get_student(student_id)
    if student is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")
    return student


@router.post("/", response_model=Student, status_code=status.HTTP_201_CREATED)
def create_student(student: StudentCreate) -> Student:
    """Save a new student to the JSON data file."""
    return add_student(student)
