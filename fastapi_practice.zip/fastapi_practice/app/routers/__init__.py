"""Student API router package."""
