"""Package container for the FastAPI practice project."""
